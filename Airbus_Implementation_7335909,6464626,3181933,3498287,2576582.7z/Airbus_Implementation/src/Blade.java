public class Blade {
    private BladeSize bladeSize;

    public Blade(BladeSize bladeSize){
        this.bladeSize = bladeSize;
    }
}
