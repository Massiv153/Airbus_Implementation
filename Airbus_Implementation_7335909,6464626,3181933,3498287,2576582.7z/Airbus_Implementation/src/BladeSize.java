public enum BladeSize {
    S, M, L
}
