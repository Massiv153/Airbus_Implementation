public class HumanBody extends BodyPart{
    public HumanBody(){
        super("Body.java",null);
    }
}
