public interface IJetEngineMediator {
    void startup();

    void setSpeed(int mph);

    void shutdown();
}
