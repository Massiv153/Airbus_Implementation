public class HumanLeg extends BodyPart{
    public HumanLeg(String side) {
        super("Leg", side);
    }
}
