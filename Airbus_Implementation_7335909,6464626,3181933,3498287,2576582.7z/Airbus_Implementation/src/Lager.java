public class Lager {
    private CheckInDesk checkInDesk;

    Baggage[][][] baggageArray = new Baggage[10][10][5];
}

