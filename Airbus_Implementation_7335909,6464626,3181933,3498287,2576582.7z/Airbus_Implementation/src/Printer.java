public class Printer {
    private CheckInDesk checkInDesk;


}
