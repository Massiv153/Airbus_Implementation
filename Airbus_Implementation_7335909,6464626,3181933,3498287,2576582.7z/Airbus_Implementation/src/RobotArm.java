public class RobotArm {

    public RobotArm(){

    }
    public void addBaggagetoLager(){

    }

    //public void sortContainers(Container[] containers, Baggage[] baggages){
      //  Baggage baggage;

    //}
}
