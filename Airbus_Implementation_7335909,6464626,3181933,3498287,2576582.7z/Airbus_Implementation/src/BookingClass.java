public enum BookingClass {
    ECONOMY, PREMIUM_ECONOMY, BUSINESS
}
