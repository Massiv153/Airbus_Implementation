public class HumanIris {


    private String humanIris;
    public HumanIris(String humanIris){
        this.humanIris = humanIris;
    }
    public String getHumanIris() {
        return humanIris;
    }
}
