public enum CabinType {
    BUSINESS_CLASS, PREMIUM_ECONOMY, ECONOMY
}
