public class AutonomousVehicle {
}
