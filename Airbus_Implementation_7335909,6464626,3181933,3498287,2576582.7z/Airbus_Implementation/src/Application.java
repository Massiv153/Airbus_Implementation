public class Application {
    public static void main(String[] args){
        Airport airport = new Airport();




    }
}
