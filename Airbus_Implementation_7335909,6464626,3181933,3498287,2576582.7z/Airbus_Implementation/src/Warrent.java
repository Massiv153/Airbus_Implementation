public enum Warrent {
    YES, NO
}
