public class BaggageLager {
    private CheckInDesk checkInDesk;

    public BaggageLager(){
        Baggage[][][] baggageArray = new Baggage[10][10][5];
        RobotArm robotArm = new RobotArm();

    }


}

