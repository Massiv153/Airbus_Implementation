public class HumanHead extends BodyPart{
    public HumanHead(){
        super("Kopf",null);
    }
}
