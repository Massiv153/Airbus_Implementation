public class CombustionChamber {
}
