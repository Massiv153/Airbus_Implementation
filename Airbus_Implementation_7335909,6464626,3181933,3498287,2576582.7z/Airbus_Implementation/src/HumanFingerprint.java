public class HumanFingerprint {
    String humanFingerprint;
    public HumanFingerprint(String humanFingerprint){
        this.humanFingerprint = humanFingerprint;
    }
}
