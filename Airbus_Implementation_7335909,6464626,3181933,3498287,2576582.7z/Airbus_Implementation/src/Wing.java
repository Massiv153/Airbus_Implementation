public class Wing {
    private JetEngine jetEngine;

    public Wing(JetEngine jetEngine){
        this.jetEngine = jetEngine;
    }
}
