public class Wartebereich {
    private CheckInDesk checkInDesk;

    Wartebereich[][] wartebereichArray = new Wartebereich[20][30];
}
