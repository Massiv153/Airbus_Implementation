public class HumanArm extends BodyPart{
    public HumanArm(String side){
        super("Arm",side);
    }

}
