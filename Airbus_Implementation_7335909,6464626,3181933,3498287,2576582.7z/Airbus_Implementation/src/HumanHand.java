public class HumanHand extends BodyPart{
    public HumanHand(String side){
        super("Hand", side);
    }
}
