public enum Priority {
    BUSINESS, PREMIUM_ECONOMY, ECONOMY
}
